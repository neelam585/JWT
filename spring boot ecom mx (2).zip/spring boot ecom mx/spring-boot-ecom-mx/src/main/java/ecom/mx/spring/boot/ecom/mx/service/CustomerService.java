package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Customer;
import ecom.mx.spring.boot.ecom.mx.payload.CustomerDTO;
import ecom.mx.spring.boot.ecom.mx.payload.CustomerResponse;

import java.util.List;

public interface CustomerService {
    Customer createCustomer(CustomerDTO customerDTO);
    List<Customer> getAllCustomers();
}

package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Product;
import ecom.mx.spring.boot.ecom.mx.payload.ProductDTO;
import ecom.mx.spring.boot.ecom.mx.payload.ProductResponse;

import java.util.List;

public interface ProductService {
    ProductResponse createProduct(ProductDTO productDTO);
    List<Product> getAllProducts();
}

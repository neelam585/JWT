package ecom.mx.spring.boot.ecom.mx.repository;

import ecom.mx.spring.boot.ecom.mx.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

}

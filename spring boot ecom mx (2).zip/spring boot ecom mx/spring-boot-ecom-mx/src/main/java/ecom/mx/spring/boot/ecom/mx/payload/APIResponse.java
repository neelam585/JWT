package ecom.mx.spring.boot.ecom.mx.payload;

public class APIResponse extends RuntimeException{
     private String message;
     public boolean status;

     public APIResponse(String message) {
          super();
     }
     public APIResponse() {

     }


     public APIResponse(String message, boolean b) {
     }
}

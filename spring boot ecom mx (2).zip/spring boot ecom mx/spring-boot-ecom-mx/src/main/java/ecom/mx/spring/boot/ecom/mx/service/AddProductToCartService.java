package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Cart;
import ecom.mx.spring.boot.ecom.mx.payload.CartDTO;

import java.util.List;

public interface AddProductToCartService {
    void addProductToCart(Long customerId, Long productId, Integer quantity);
    List<Cart> getAllCarts();
}

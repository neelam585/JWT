package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Order;

import java.util.List;

public interface OrderService {
    void createOrder(Long cartId);
List<Order> getAllOrders();
}

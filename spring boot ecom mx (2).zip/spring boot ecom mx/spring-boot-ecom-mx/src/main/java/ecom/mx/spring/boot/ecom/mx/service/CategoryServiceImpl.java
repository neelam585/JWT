package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Category;
import ecom.mx.spring.boot.ecom.mx.payload.CategoryDTO;
import ecom.mx.spring.boot.ecom.mx.repository.CategoryRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Override
    public Category createCategory(CategoryDTO categoryDTO) {

        Category category = modelMapper.map(categoryDTO, Category.class);
        return categoryRepository.save(category);
    }
    @Override
    public List<Category> getAllCategories() {
       return  categoryRepository.findAll();
    }
}

package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Product;
import ecom.mx.spring.boot.ecom.mx.payload.ProductDTO;
import ecom.mx.spring.boot.ecom.mx.payload.ProductResponse;
import ecom.mx.spring.boot.ecom.mx.repository.ProductRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public ProductResponse createProduct(ProductDTO productDTO){
        Product productResquestData = modelMapper.map(productDTO, Product.class);
        Product productdata = productRepository.save(productResquestData);
        return modelMapper.map(productdata, ProductResponse.class);

    }
    @Override
    public List<Product> getAllProducts(){
        return productRepository.findAll();
    }

}

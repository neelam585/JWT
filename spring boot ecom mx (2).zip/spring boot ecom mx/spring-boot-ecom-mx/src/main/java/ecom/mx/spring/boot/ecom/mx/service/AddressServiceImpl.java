package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Address;
import ecom.mx.spring.boot.ecom.mx.model.Customer;
import ecom.mx.spring.boot.ecom.mx.payload.AddressDTO;
import ecom.mx.spring.boot.ecom.mx.repository.AddressRepository;
import ecom.mx.spring.boot.ecom.mx.repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddressServiceImpl implements AddressService{
    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Address createAddress(Long customerId ,AddressDTO addressDTO){
        Customer customer = customerRepository.findById(customerId).get();
        Address address = modelMapper.map(addressDTO, Address.class);
        address.setCustomer(customer);
        return addressRepository.save(address);
    }
    @Override
    public List<Address> getAllAddresses(){
        return addressRepository.findAll();
    }
}

package ecom.mx.spring.boot.ecom.mx.controller;

import ecom.mx.spring.boot.ecom.mx.model.Address;
import ecom.mx.spring.boot.ecom.mx.payload.AddressDTO;
import ecom.mx.spring.boot.ecom.mx.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class AddressController {
    @Autowired
    private AddressService addressService;

    @PostMapping("/address/customer/{customerId}")
    public Address createAddress(@PathVariable Long customerId ,@RequestBody AddressDTO addressDTO){
        return addressService.createAddress(customerId,addressDTO);

    }
    @GetMapping("/addresses")
    public List<Address> getAllAddresses(){
        return addressService.getAllAddresses();
    }
}

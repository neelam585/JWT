package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Cart;
import ecom.mx.spring.boot.ecom.mx.model.CartItem;
import ecom.mx.spring.boot.ecom.mx.model.Customer;
import ecom.mx.spring.boot.ecom.mx.model.Product;
import ecom.mx.spring.boot.ecom.mx.payload.CartDTO;
import ecom.mx.spring.boot.ecom.mx.repository.CartItemRepository;
import ecom.mx.spring.boot.ecom.mx.repository.CartRepository;
import ecom.mx.spring.boot.ecom.mx.repository.CustomerRepository;
import ecom.mx.spring.boot.ecom.mx.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AddProductToCartServiceImpl implements AddProductToCartService {
    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private CartItemRepository cartItemRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public void addProductToCart(Long customerId, Long productId, Integer quantity){
        Customer customer = customerRepository.findById(customerId).orElse(null);
        Product product = productRepository.findById(productId).orElse(null);

        //return cartItemRepository.addProductToCart(productId,quantity);
        Optional<CartItem> existingCartItem = cartItemRepository.findById(productId);

        Cart cart = new Cart();
        cart.setCustomer(customer);
        cart.setTotalPrice(product.getPrice() * quantity);
        Cart cartSave = cartRepository.save(cart);

        CartItem cartItem = new CartItem();
        cartItem.setCart(cartSave);
        cartItem.setProduct(product);
        cartItem.setQuantity(quantity);
        cartItemRepository.save(cartItem);

    }
    @Override
    public List<Cart> getAllCarts(){
        return cartRepository.findAll();
    }
}

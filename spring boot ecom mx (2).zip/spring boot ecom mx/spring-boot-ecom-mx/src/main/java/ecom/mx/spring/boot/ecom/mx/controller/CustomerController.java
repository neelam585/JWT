package ecom.mx.spring.boot.ecom.mx.controller;

import ecom.mx.spring.boot.ecom.mx.model.Customer;
import ecom.mx.spring.boot.ecom.mx.payload.CustomerDTO;
import ecom.mx.spring.boot.ecom.mx.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/customer")
    public Customer createCustomer(@RequestBody CustomerDTO customerDTO){
        return customerService.createCustomer(customerDTO);
    }
    @GetMapping("/customers")
    public Iterable<Customer> getAllCustomers(){
        return customerService.getAllCustomers();
    }

}

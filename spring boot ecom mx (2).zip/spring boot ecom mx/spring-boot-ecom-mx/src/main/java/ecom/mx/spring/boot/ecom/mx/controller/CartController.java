package ecom.mx.spring.boot.ecom.mx.controller;

import ecom.mx.spring.boot.ecom.mx.model.Cart;
import ecom.mx.spring.boot.ecom.mx.payload.CartDTO;
import ecom.mx.spring.boot.ecom.mx.service.AddProductToCartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class CartController {
    @Autowired
    private AddProductToCartService addProductToCartService;

    @PostMapping("/cart/add/product/{customerId}/{productId}/{quantity}")
    public void addProductToCart(@PathVariable Long customerId, @PathVariable Long productId, @PathVariable  Integer quantity){
         addProductToCartService.addProductToCart(customerId,productId,quantity);
    }
    @GetMapping("/carts")
    public List<Cart> getAllCarts(){
        return addProductToCartService.getAllCarts();
    }
}

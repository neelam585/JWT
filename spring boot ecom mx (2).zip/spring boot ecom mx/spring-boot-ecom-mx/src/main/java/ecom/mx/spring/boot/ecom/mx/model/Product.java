package ecom.mx.spring.boot.ecom.mx.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;
    private String name;
    private String sku;
    private String image;
    private Double price;
    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;


}

package ecom.mx.spring.boot.ecom.mx.controller;

import com.sun.net.httpserver.HttpServer;
import ecom.mx.spring.boot.ecom.mx.model.Category;
import ecom.mx.spring.boot.ecom.mx.payload.CategoryDTO;
import ecom.mx.spring.boot.ecom.mx.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class CategoryController {
    @Autowired
    private CategoryService categoryService;

    @PostMapping("/category")
    public ResponseEntity<Category> createCategory(@RequestBody CategoryDTO categoryDTO){
        return new ResponseEntity<Category>(categoryService.createCategory(categoryDTO), HttpStatus.CREATED);


    }
    @GetMapping("/categories")
    public List<Category> getAllCategories(){
        return categoryService.getAllCategories();
    }
}

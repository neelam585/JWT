package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Customer;
import ecom.mx.spring.boot.ecom.mx.payload.CustomerDTO;
import ecom.mx.spring.boot.ecom.mx.payload.CustomerResponse;
import ecom.mx.spring.boot.ecom.mx.repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Override
    public Customer createCustomer(CustomerDTO customerDTO) {
        Customer customer = modelMapper.map(customerDTO, Customer.class);

        return customerRepository.save(customer);
    }
    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

}

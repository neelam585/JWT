package ecom.mx.spring.boot.ecom.mx.controller;

import ecom.mx.spring.boot.ecom.mx.model.Product;
import ecom.mx.spring.boot.ecom.mx.payload.ProductDTO;
import ecom.mx.spring.boot.ecom.mx.payload.ProductResponse;
import ecom.mx.spring.boot.ecom.mx.service.CustomerService;
import ecom.mx.spring.boot.ecom.mx.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api")
public class ProductController {
    @Autowired
    private ProductService productService;

    @PostMapping("/product")
    public ResponseEntity<ProductResponse> createProduct(@RequestBody ProductDTO productDTO){
        return new ResponseEntity<ProductResponse>(productService.createProduct(productDTO), HttpStatus.CREATED);
    }
    @GetMapping("/products")
    public Iterable<Product> getAllProducts(){
        return productService.getAllProducts();
    }
}

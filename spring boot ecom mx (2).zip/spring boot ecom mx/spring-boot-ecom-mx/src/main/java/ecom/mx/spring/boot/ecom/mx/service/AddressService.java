package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.Address;
import ecom.mx.spring.boot.ecom.mx.payload.AddressDTO;

import java.util.List;

public interface AddressService {
    Address createAddress(Long customerId,AddressDTO addressDTO);
    List<Address> getAllAddresses();

}

package ecom.mx.spring.boot.ecom.mx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEcomMxApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEcomMxApplication.class, args);
	}

}

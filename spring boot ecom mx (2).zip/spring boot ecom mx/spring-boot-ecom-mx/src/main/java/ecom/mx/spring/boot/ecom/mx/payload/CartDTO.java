package ecom.mx.spring.boot.ecom.mx.payload;

import ecom.mx.spring.boot.ecom.mx.model.CartItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartDTO {
    private Long cartId;
    private Double totalPrice;
    private String userName;
    private String email;
    private List<CartItem> cartItem;
}

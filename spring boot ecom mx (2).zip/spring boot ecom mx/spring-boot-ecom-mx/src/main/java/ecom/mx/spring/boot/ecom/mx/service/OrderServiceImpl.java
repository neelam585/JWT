package ecom.mx.spring.boot.ecom.mx.service;

import ecom.mx.spring.boot.ecom.mx.model.*;
import ecom.mx.spring.boot.ecom.mx.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class OrderServiceImpl implements OrderService{
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private CartItemRepository cartItemRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private OrderItemRepository orderItemRepository;


    @Override
    public void createOrder(Long cartId) {
      Cart cart = cartRepository.findById(cartId).orElse(null);
      //System.out.println(cart.getCustomer());
      Order order = new Order();
      order.setCustomerName(cart.getCustomer().getFirstName());
      order.setCustomerEmail(cart.getCustomer().getEmail());
      order.setTotalAmount(cart.getTotalPrice());
      Order savedOrder = orderRepository.save(order);

      //CartItem cartItem = cartItemRepository.findById(cartId).orElse(null);
        List<CartItem> cartItems = cart.getCartItems(); // Assuming Cart has a One-to-Many relationship with CartItem
        for (CartItem cartItem : cartItems) {
            Product product = productRepository.findById(cartItem.getProduct().getProductId()).orElse(null);
            OrderItem orderItem = new OrderItem();
            orderItem.setProductName(product.getName());
            orderItem.setPrice(product.getPrice());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setOrder(savedOrder);
            OrderItem savedOrderItem = orderItemRepository.save(orderItem);

        }

    }
    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

}

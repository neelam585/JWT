package ecom.mx.spring.boot.ecom.mx.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long customerId;;
    private String firstName;
    private String lastName;
    private String userName;
    private String email;
    private String password;
    @OneToMany(mappedBy = "customer")
    private List<Address> addresses;
}

package com.ecom.Testing.controller;

import com.ecom.Testing.dto.ProductRequestDTO;
import com.ecom.Testing.dto.ProductResponseDTO;
import com.ecom.Testing.model.Product;
import com.ecom.Testing.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/product/create")
    public Product createProduct(
            @RequestPart ProductRequestDTO productRequestDTO,
            @RequestPart("file") MultipartFile imageFile
    ){
        return productService.saveProduct(productRequestDTO,imageFile);
    }

    @GetMapping("/product/category")
    public ProductResponseDTO getProduct(
            @RequestParam(required = false) Long catId,
            @RequestParam(defaultValue = "0",required = false) int pageNumber,
            @RequestParam(defaultValue = "10" ,required = false) int pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String color,
            @RequestParam(required = false) String size
            ){
        return productService.productListByCategory(catId,pageNumber,pageSize,name,minPrice,maxPrice,color,size);
    }
}

package com.ecom.Testing.model;

public enum Status {
    ACTIVE,
    INACTIVE
}

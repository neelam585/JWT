package com.ecom.Testing.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressRequestDTO {

    private String firstName;
    private String lastName;
    private String street;
    private String city;
    private String state;
    private String country;
    private Integer pinCode;
    private String mobileNumber;
    private String status;

}

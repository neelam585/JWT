package com.ecom.Testing.dto;

import com.ecom.Testing.model.Status;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductRequestDTO {

    private String name;

    private String sku;


    private Float price;
    private String image;
    private Integer qty;

    private Integer stock;

    private Status status;
}

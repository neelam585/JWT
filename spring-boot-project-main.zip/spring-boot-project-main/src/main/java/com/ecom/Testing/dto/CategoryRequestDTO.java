package com.ecom.Testing.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CategoryRequestDTO {

    private String CategoryName;
    private String Status;
}

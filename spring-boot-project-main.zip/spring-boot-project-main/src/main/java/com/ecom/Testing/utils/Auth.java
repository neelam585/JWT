package com.ecom.Testing.utils;

import com.ecom.Testing.model.Customer;
import com.ecom.Testing.respository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class Auth {

    @Autowired
    private CustomerRepository customerRepository;

    public String loggedInEmail(){
        return getCustomer().getEmail();
    }

    public String loggedInUsername(){
        return getCustomer().getUserName();
    }

    public Long loggedInUserId(){
        return getCustomer().getId();
    }

    public Customer getCustomer(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Customer customer = customerRepository.findByUserName(authentication.getName());
        if(customer==null){
            throw new RuntimeException("customer does not exist");
        }

        return customer;
    }
}

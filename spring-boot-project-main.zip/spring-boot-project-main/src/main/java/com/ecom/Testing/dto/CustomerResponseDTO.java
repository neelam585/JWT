package com.ecom.Testing.dto;

import com.ecom.Testing.model.Address;
import com.ecom.Testing.model.Roles;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerResponseDTO {
    private String firstName;
    private String lastName;
    private String userName;
    private String email;
    private Set<Roles> role;
    private List<Address> addresses;
}

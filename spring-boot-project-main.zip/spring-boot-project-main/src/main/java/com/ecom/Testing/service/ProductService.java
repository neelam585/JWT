package com.ecom.Testing.service;

import com.ecom.Testing.dto.APIResponse;
import com.ecom.Testing.dto.ProductRequestDTO;
import com.ecom.Testing.dto.ProductResponseDTO;
import com.ecom.Testing.model.Product;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ProductService {

     public Product saveProduct(ProductRequestDTO productRequestDTO, MultipartFile imageFile);

     public ProductResponseDTO productListByCategory(Long catId, Integer page, Integer pageSize,String name,Double minPrice,Double maxPrice,String color,String size);

     public Product deleteProduct(Long id);

     public Product updateProduct(Long id, ProductRequestDTO productRequestDTO, MultipartFile imageFile);
}

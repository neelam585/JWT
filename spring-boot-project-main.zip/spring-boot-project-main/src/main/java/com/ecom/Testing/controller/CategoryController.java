package com.ecom.Testing.controller;

import com.ecom.Testing.dto.APIResponse;
import com.ecom.Testing.dto.CategoryRequestDTO;
import com.ecom.Testing.dto.CategoryResponseDTO;
import com.ecom.Testing.model.Category;
import com.ecom.Testing.service.CategoryServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("api")
public class CategoryController {

    @Autowired
    private CategoryServiceImpl categoryService;

    @PostMapping("category/create")
    public ResponseEntity<Category> createCategory(@RequestBody CategoryRequestDTO categoryRequestDTO){
        Category saveCategory = categoryService.saveCategory(categoryRequestDTO);
        return new ResponseEntity<>(saveCategory,HttpStatus.CREATED);
    }

    @GetMapping("category/list")
    public ResponseEntity<List<Category>> getAllCategory(){
        return new ResponseEntity<>(categoryService.getAllCategory(),HttpStatus.OK);
    }

    @DeleteMapping("category/delete/{id}")
    public ResponseEntity<Category> deleteCategory(@PathVariable Long id){
         Category categoryresponse =  categoryService.deleteCategory(id);
         return new ResponseEntity<>(categoryresponse,HttpStatus.OK);
    }

    @PutMapping("category/update/{id}")
    public ResponseEntity<Category> updatecategory(@RequestBody CategoryRequestDTO categoryRequestDTO, @PathVariable Long id){
       Category categoryResponse = categoryService.updateCategory(categoryRequestDTO,id);
        return new ResponseEntity<>(categoryResponse,HttpStatus.OK);
    }

}

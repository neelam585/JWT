package com.ecom.Testing.respository;

import com.ecom.Testing.model.Product;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Repository;

@Repository
public class ProductSpecfication {
    public static Specification<Product> hasName(String name){
        return (root,query,builder)->
            builder.like(builder.lower(root.get("name")), "%"+name.toLowerCase()+"%");
    }

    public static Specification<Product> hasPriceBetween(Double minPrice, Double maxPrice){
        return (root,query,builder)->
                builder.between(root.get("price"),minPrice,maxPrice);
    }

    public static Specification<Product> hasColor(String color){
        return (root,query,builder)->
                builder.equal(root.get("color"),color);
    }

    public static Specification<Product> hasSize(String size){
        return (root,query,builder)->
                builder.equal(root.get("size"),size);
    }


}

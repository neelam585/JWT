package com.ecom.Testing.service;

import com.ecom.Testing.dto.AddressRequestDTO;
import com.ecom.Testing.model.Address;
import com.ecom.Testing.model.Customer;
import com.ecom.Testing.respository.AddressRepository;
import com.ecom.Testing.respository.CustomerRepository;
import com.ecom.Testing.utils.Auth;
import org.apache.coyote.BadRequestException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AddressServiceImpl implements AddressService{

    @Autowired
    private Auth auth;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Address createAddress(AddressRequestDTO addressRequestDTO) {
        Customer customer = customerRepository.findById(auth.loggedInUserId()).orElseThrow(() -> new RuntimeException("customer is not valid"));
        Address address = modelMapper.map(addressRequestDTO, Address.class);
        address.setCustomer(customer);
        try {
            return addressRepository.save(address);
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String deleteAddress(Long addressId) {
        addressRepository.findById(addressId)
               .orElseThrow(()->new RuntimeException("Address Id does not exist"));
       try {
           addressRepository.deleteById(addressId);
           return "address deleted successfully";
       } catch (RuntimeException e) {
           throw new RuntimeException(e);
       }
    }

    @Override
    public Address updateAddress(AddressRequestDTO addressRequestDTO,Long addressId) {
      return addressRepository.findById(addressId).map(address->{
              modelMapper.map(addressRequestDTO,address);
          try {
              return addressRepository.save(address);
          } catch (DataIntegrityViolationException e) {
              try {
                  throw new BadRequestException("Invalid address data: " + e.getMostSpecificCause().getMessage());
              } catch (BadRequestException ex) {
                  throw new RuntimeException(ex);
              }
          } catch (Exception e) {
              throw new RuntimeException("Error while saving address: " + e.getMessage());
          }
      }).orElseThrow(()->new RuntimeException("Address Id does not exist"));


    }

    @Override
    public List<Address> getAddresByCustomer() {
        Customer customer = customerRepository.findById(auth.loggedInUserId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        List<Address> addresses = customer.getAddresses();
        return addresses;
    }

    @Override
    public List<Address> getAllAddress() {
        return addressRepository.findAll();
    }



}

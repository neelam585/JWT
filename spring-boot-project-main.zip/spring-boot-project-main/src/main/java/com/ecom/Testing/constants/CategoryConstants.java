package com.ecom.Testing.constants;

public class CategoryConstants {
    public static final int ACTIVE = 1;
    public static final int INACTIVE = 0;

    private CategoryConstants() {} // prevent instantiation
}

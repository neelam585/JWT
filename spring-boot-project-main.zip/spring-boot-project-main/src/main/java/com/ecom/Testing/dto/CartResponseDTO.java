package com.ecom.Testing.dto;

import com.ecom.Testing.model.CartItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartResponseDTO {

    private String name;
    private String userName;
    private String email;
    private Float discount;
    private Float subtotal;
    private Float grandTotal;
    private List<CartItemDTO> cartItemList;

}

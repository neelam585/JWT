package com.ecom.Testing.service;

import com.ecom.Testing.dto.CustomerRequestDTO;
import com.ecom.Testing.dto.CustomerResponseDTO;
import com.ecom.Testing.dto.LoginDTO;
import com.ecom.Testing.dto.LoginResponseDTO;
import com.ecom.Testing.model.Customer;
import com.ecom.Testing.model.CustomerRole;
import com.ecom.Testing.model.Roles;
import com.ecom.Testing.respository.CustomerRepository;
import com.ecom.Testing.respository.RoleRespository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private RoleRespository roleRespository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtService jwtService;

    private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder(12);

    @Override
    public CustomerResponseDTO register(CustomerRequestDTO customerRequestDTO) {

        Customer checkUserName = customerRepository.findByUserName(customerRequestDTO.getUserName());
        if(checkUserName != null){
            throw new RuntimeException("username is already exist");
        }
        Customer customer = new Customer();
        customer.setFirstName(customerRequestDTO.getFirstName());
        customer.setLastName(customerRequestDTO.getLastName());
        customer.setUserName(customerRequestDTO.getUserName());
        customer.setEmail(customerRequestDTO.getEmail());
        customer.setPassword(encoder.encode(customerRequestDTO.getPassword()));

        List<Roles> roles = customerRequestDTO.getRoles().stream()
                .map(role -> {
                    CustomerRole enumRole = CustomerRole.valueOf(role); // Converts "ADMINUSER" to CustomerRole.ADMINUSER
                    return roleRespository.findByRoleName(enumRole)
                            .orElseThrow(() -> new RuntimeException("Role name does not exist: " + role));
                })
                .collect(Collectors.toList());
        customer.setRoles(roles);
        Customer saveData = customerRepository.save(customer);
        return modelMapper.map(saveData,CustomerResponseDTO.class);
    }

    @Override
    public LoginResponseDTO login(LoginDTO loginDTO) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginDTO.getUserName(),loginDTO.getPassword()));
       if(authentication.isAuthenticated()){
           Customer customer = customerRepository.findByUserName(loginDTO.getUserName());
          String token = jwtService.generateToken(loginDTO.getUserName());
          LoginResponseDTO loginResponseDTO = new LoginResponseDTO();
          loginResponseDTO.setUserName(loginDTO.getUserName());
          loginResponseDTO.setToken(token);
          loginResponseDTO.setRoles(customer.getRoles());
          return loginResponseDTO;
       }else{
           throw new RuntimeException("Username or passwor is invalid");
       }
    }

    @Override
    public Customer deleteCustomer(Long id) {
        return null;
    }

    @Override
    public Customer updateCustomer(CustomerRequestDTO customerRequestDTO, Long id) {
        return null;
    }
}

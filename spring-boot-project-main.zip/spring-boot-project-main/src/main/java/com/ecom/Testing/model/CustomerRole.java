package com.ecom.Testing.model;

import aj.org.objectweb.asm.commons.Remapper;

public enum CustomerRole {
    ADMINUSER,
    NORMALUSER,
    SELLER;
}

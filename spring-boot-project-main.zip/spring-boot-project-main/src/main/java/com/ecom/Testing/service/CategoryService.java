package com.ecom.Testing.service;

import com.ecom.Testing.dto.APIResponse;
import com.ecom.Testing.dto.CategoryRequestDTO;
import com.ecom.Testing.dto.CategoryResponseDTO;
import com.ecom.Testing.model.Category;

import java.util.List;

public interface CategoryService {

    public Category saveCategory(CategoryRequestDTO categoryRequestDTO);

    public List<Category> getAllCategory();

    public Category deleteCategory(Long id);

    public Category updateCategory(CategoryRequestDTO categoryRequestDTO,Long id);

}

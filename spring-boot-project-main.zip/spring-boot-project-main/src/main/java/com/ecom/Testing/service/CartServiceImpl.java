package com.ecom.Testing.service;

import com.ecom.Testing.dto.*;
import com.ecom.Testing.model.*;
import com.ecom.Testing.respository.*;
import com.ecom.Testing.utils.Auth;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartServiceImpl implements CartService{

    @Autowired
    private ProductRespository productRespository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private Auth auth;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AddressRepository addressRepository;

    @Override
    public CartResponseDTO addToCart(CartRequestDTO cartRequestDTO) {
        Customer customerRecord = customerRepository.findByUserName(auth.loggedInUsername());
        if(customerRecord == null){
            throw new RuntimeException("user is not exist in our database");
        }

        Cart cart = createCart(customerRecord);

        Product productRecord = productRespository.findById(cartRequestDTO.getProductId())
                .orElseThrow(() -> new RuntimeException("product does not exist"));
       CartItem checkCartitem = cartItemRepository.findCartItemByProductIdAndCartId(cart.getId(),cartRequestDTO.getProductId());
        if(checkCartitem!=null){
            throw new RuntimeException("this product is already exist in the cart");
        }

           CartItem cartItem = new CartItem();
           cartItem.setProduct(productRecord);
           cartItem.setQty(cartRequestDTO.getQty());
           cartItem.setPrice(productRecord.getPrice());
           cartItem.setCart(cart);
           CartItem cartItemSave = cartItemRepository.save(cartItem);



        Float subtotal = cart.getSubTotal()+(productRecord.getPrice()*cartRequestDTO.getQty());
        cart.setGrandTotal(subtotal);
        cart.setSubTotal(subtotal);
        Cart cartSave = cartRepository.save(cart);
        cart.getCartItems().add(cartItem);

        CartResponseDTO cartResponse = new CartResponseDTO();
        cartResponse.setName(customerRecord.getFirstName()+" "+customerRecord.getLastName());
        cartResponse.setEmail(customerRecord.getEmail());
        cartResponse.setUserName(customerRecord.getUserName());
        cartResponse.setGrandTotal(cartSave.getGrandTotal());
        cartResponse.setSubtotal(cartSave.getSubTotal());
        cartResponse.setDiscount(cartSave.getDiscount());

        List<CartItem> cartItems = cartSave.getCartItems();
        List<CartItemDTO> cartItemddto = cartItems.stream().map(cartitem->{
            CartItemDTO CartoDB = modelMapper.map(cartitem,CartItemDTO.class);
            CartoDB.setName(cartitem.getProduct().getName());
            CartoDB.setSku(cartitem.getProduct().getSku());
            return CartoDB;
        }).toList();
        cartResponse.setCartItemList(cartItemddto);
        return cartResponse;

    }

    public Cart createCart(Customer customer){
        Cart checkUserInCart = cartRepository.findCartByEmail(auth.loggedInEmail());
        if(checkUserInCart == null){
            Cart createCart = new Cart();
            createCart.setCustomer(customer);
            createCart.setSubTotal(0.00F);
            createCart.setGrandTotal(0.00F);
            createCart.setDiscount(0.00F);
          return  cartRepository.save(createCart);
        }
        return checkUserInCart;
    }

    @Override
    public CartResponseDTO getCart(){
        String  currentUser = auth.loggedInUsername();
        Customer customerRecord = customerRepository.findByUserName(currentUser);
        Cart cartData = cartRepository.findCartByEmail(currentUser);
        CartResponseDTO cartResponse = new CartResponseDTO();
        cartResponse.setName(customerRecord.getFirstName()+" "+customerRecord.getLastName());
        cartResponse.setEmail(customerRecord.getEmail());
        cartResponse.setUserName(customerRecord.getUserName());
        cartResponse.setGrandTotal(cartData.getGrandTotal());
        cartResponse.setSubtotal(cartData.getSubTotal());
        cartResponse.setDiscount(cartData.getDiscount());

        List<CartItem> cartItems = cartData.getCartItems();
        List<CartItemDTO> cartItemddto = cartItems.stream().map(cartitem->{
            CartItemDTO CartoDB = modelMapper.map(cartitem,CartItemDTO.class);
            CartoDB.setName(cartitem.getProduct().getName());
            CartoDB.setSku(cartitem.getProduct().getSku());
            return CartoDB;
        }).toList();
        cartResponse.setCartItemList(cartItemddto);
        return cartResponse;
    }

    @Override
    public String deleteCartById(Long cartItemId) {
        cartItemRepository.findById(cartItemId)
                .orElseThrow(()->new RuntimeException("cart item id does not exist"));
        try {
            cartItemRepository.deleteById(cartItemId);
            Cart cart = cartRepository.findCartByEmail(auth.loggedInEmail());
            float totalAmount = (float) cart.getCartItems().stream()
                    .mapToDouble(item -> item.getPrice() * item.getQty())
                    .sum();
            cart.setGrandTotal(totalAmount);
            cart.setSubTotal(totalAmount);
            cartRepository.save(cart);
            return "cart item deleted successfully";
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String deleteAllItem(Long cartId) {
        cartRepository.findById(cartId)
                .orElseThrow(()->new RuntimeException("cart id does not exist"));
        try {
            cartItemRepository.deleteAllCartItem(cartId);
            Cart cart = new Cart();
            cart.setDiscount(0.00F);
            cart.setGrandTotal(0.00F);
            cart.setSubTotal(0.00F);
            cartRepository.save(cart);
            return "All cart item deleted successfully";
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String updateCart(CartUpdateRequestDTO cartUpdateRequestDTO) {

        try {
            CartItem cartItem = cartItemRepository.findById(cartUpdateRequestDTO.getCartItemId())
                    .orElseThrow(() -> new RuntimeException("CartItem not found with ID: " + cartUpdateRequestDTO.getCartItemId()));

            cartItem.setQty(cartUpdateRequestDTO.getQty());
            cartItemRepository.save(cartItem);

            Cart cart = cartRepository.findCartByEmail(auth.loggedInEmail());
            float totalAmount = (float) cart.getCartItems().stream()
                    .mapToDouble(item -> item.getPrice() * item.getQty())
                    .sum();
            cart.setGrandTotal(totalAmount);
            cart.setSubTotal(totalAmount);
            cartRepository.save(cart);

            return "cart update successfully";
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public String updateAddressInCart(Long addressId)
    {
        Address addressFromDB = addressRepository.findById(addressId).orElseThrow(()->new RuntimeException("invalid address id"));
        Cart cart = cartRepository.findCartByEmail(auth.loggedInUsername());
        cart.setAddress(addressFromDB);
        cartRepository.save(cart);
        return "Address updated successfully";
    }
}

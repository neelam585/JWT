package com.ecom.Testing.controller;

import com.ecom.Testing.dto.AddressRequestDTO;
import com.ecom.Testing.model.Address;
import com.ecom.Testing.service.AddressService;
import com.ecom.Testing.service.AddressServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class AddressController {

    @Autowired
    private AddressServiceImpl addressService;

    @PostMapping("customer/address")
    public ResponseEntity<Address> createAddress(@RequestBody AddressRequestDTO addressRequestDTO){
       Address response = addressService.createAddress(addressRequestDTO);
       return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("all/address")
    public ResponseEntity<List<Address>> getAllAddress(){
        List<Address> response = addressService.getAllAddress();
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    @GetMapping("customer/address")
    public ResponseEntity<List<Address>> getAddressByCustomer(){
        List<Address> response = addressService.getAddresByCustomer();
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    @DeleteMapping("customer/address/{customerId}")
    public ResponseEntity<String> addressDelete(@PathVariable Long customerId){
        String response = addressService.deleteAddress(customerId);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    @PutMapping("customer/address/{customerId}")
    public ResponseEntity<Address> addressDelete(@RequestBody AddressRequestDTO addressRequestDTO, @PathVariable Long customerId){
        Address response = addressService.updateAddress(addressRequestDTO,customerId);
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
}

package com.ecom.Testing.service;

import com.ecom.Testing.dto.ProductRequestDTO;
import com.ecom.Testing.dto.ProductResponseDTO;
import com.ecom.Testing.model.Product;
import com.ecom.Testing.respository.ProductRespository;
import com.ecom.Testing.respository.ProductSpecfication;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductRespository productRespository;

    private static final String UPLOAD_DIR = "image_upload";

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Product saveProduct(ProductRequestDTO productRequestDTO, MultipartFile imageFile) {
        Optional<Product> existingProduct = Optional.ofNullable(productRespository.findBySku(productRequestDTO.getSku()));
        if (existingProduct.isPresent()) {
            throw new RuntimeException("Product with SKU '" + productRequestDTO.getSku() + "' already exists.");
        }

        try {
            // Save image to disk
            String fileName = UUID.randomUUID() + "_" + imageFile.getOriginalFilename();
            Path imagePath = Paths.get(UPLOAD_DIR, fileName);
            Files.createDirectories(imagePath.getParent());
            Files.write(imagePath, imageFile.getBytes());

            // Map DTO to entity
            Product product = new Product();
            product.setName(productRequestDTO.getName());
            product.setSku(productRequestDTO.getSku());
            product.setPrice(productRequestDTO.getPrice());
            product.setQty(productRequestDTO.getQty());
            product.setImage(fileName);
            return productRespository.save(product);
        } catch (IOException ex) {
            throw new RuntimeException("Error while saving product: " + ex.getMessage(), ex);
        }
    }

    @Override
    public ProductResponseDTO productListByCategory(Long catId, Integer page, Integer pageSize, String name,Double minPrice,Double maxPrice,String color,String size) {
       // Sort sort = ascending ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(page, pageSize);
        Specification<Product> spec = Specification.where(null);

        if(name!=null){
            spec = spec.and(ProductSpecfication.hasName(name));
        }
        if(minPrice != null && maxPrice !=null){
            spec = spec.and(ProductSpecfication.hasPriceBetween(minPrice,maxPrice));
        }
        if(color!=null){
            spec = spec.and(ProductSpecfication.hasColor(color));
        }
        if(size!=null){
            spec = spec.and(ProductSpecfication.hasSize(size));
        }

        Page<Product> pageProducts = productRespository.findAll(spec,pageable);
        System.out.println("Fetched employees: " + pageProducts);
        List<Product> productList = pageProducts.getContent();
        List<ProductRequestDTO> productDTO = productList.stream().map(
                productData-> {
                    return  modelMapper.map(productData,ProductRequestDTO.class);
                }).toList();
        ProductResponseDTO productResponse = new ProductResponseDTO();
        productResponse.setContent(productDTO);
        productResponse.setPageNumber(pageProducts.getNumber());
        productResponse.setPageSize(pageProducts.getSize());
        productResponse.setTotalElements(pageProducts.getTotalElements());
        productResponse.setTotalPages(pageProducts.getTotalPages());
        productResponse.setLastPage(pageProducts.isLast());
      return productResponse;


    }

    @Override
    public Product deleteProduct(Long id) {
        return null;
    }

    @Override
    public Product updateProduct(Long id, ProductRequestDTO productRequestDTO, MultipartFile imageFile) {
        return null;
    }
}

package com.ecom.Testing.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CartItemDTO {

    private String name;
    private String sku;
    private Float price;
    private Integer qty;
}

package com.ecom.Testing.service;

import com.ecom.Testing.dto.AddressRequestDTO;
import com.ecom.Testing.model.Address;
import java.util.List;

public interface AddressService {

    public Address createAddress(AddressRequestDTO addressRequestDTO);

    public String deleteAddress(Long addressId);

    public Address updateAddress(AddressRequestDTO addressRequestDTO, Long addressId);

    public List<Address> getAddresByCustomer();

    public List<Address> getAllAddress();

}

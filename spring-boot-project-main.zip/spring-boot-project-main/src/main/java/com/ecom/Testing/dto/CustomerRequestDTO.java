package com.ecom.Testing.dto;

import com.ecom.Testing.model.Roles;
import com.ecom.Testing.model.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerRequestDTO {
    private String firstName;
    private String lastName;
    private String email;
    private String userName;
    private String password;
    private Status status;
    private List<String> roles;
}

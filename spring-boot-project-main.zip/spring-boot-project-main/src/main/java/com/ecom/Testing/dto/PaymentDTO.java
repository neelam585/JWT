package com.ecom.Testing.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaymentDTO {
    private String methodName;
    private String transitionNumber;
    private Double amount;
    private String status;
}

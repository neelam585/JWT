package com.ecom.Testing.controller;

import com.ecom.Testing.dto.CartRequestDTO;
import com.ecom.Testing.dto.CartResponseDTO;
import com.ecom.Testing.dto.CartUpdateRequestDTO;
import com.ecom.Testing.service.CartServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class CartController {

    @Autowired
    private CartServiceImpl cartService;

    @PostMapping("cart/addtocart")
    public ResponseEntity<CartResponseDTO> addToCart(@RequestBody CartRequestDTO cartRequestDTO){
        CartResponseDTO response = cartService.addToCart(cartRequestDTO);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("cart")
    public ResponseEntity<CartResponseDTO> getCart(){
        CartResponseDTO response = cartService.getCart();
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @DeleteMapping("cart/empty/{cartId}")
    public ResponseEntity<String> emptyCart(@PathVariable Long cartId){
        String response = cartService.deleteAllItem(cartId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping("cart/delete/{cartItemId}")
    public ResponseEntity<String> deleteCartItem(@PathVariable Long cartItemId){
        String response = cartService.deleteCartById(cartItemId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("cart/update")
    public ResponseEntity<String> updateCart(@RequestBody CartUpdateRequestDTO cartUpdateRequestDTO){
        String response = cartService.updateCart(cartUpdateRequestDTO);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping("cart/update/address/{addressId}")
    public ResponseEntity<String> cartUpdateAddress(@PathVariable Long addressId){
        String response = cartService.updateAddressInCart(addressId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}

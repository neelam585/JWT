package com.ecom.Testing.service;

import com.ecom.Testing.dto.APIResponse;
import com.ecom.Testing.dto.CategoryRequestDTO;
import com.ecom.Testing.dto.CategoryResponseDTO;
import com.ecom.Testing.model.Category;
import com.ecom.Testing.model.Status;
import com.ecom.Testing.respository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoryServiceImpl implements CategoryService{

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public Category saveCategory(CategoryRequestDTO categoryRequestDTO) {
        Optional.ofNullable(categoryRepository.findByCategoryName(categoryRequestDTO.getCategoryName()))
                .ifPresent(existingCategory -> {
                    throw new RuntimeException("Category already exists");
                });
       Category category = new Category();
       category.setCategoryName(categoryRequestDTO.getCategoryName());
       category.setStatus(Status.valueOf(categoryRequestDTO.getStatus()));
       return categoryRepository.save(category);
    }

    @Override
    public List<Category> getAllCategory() {
        List<Category> catdata = categoryRepository.findAll();
        catdata.stream().findAny().orElseThrow(()->
            new RuntimeException("No category Data found")
        );
        return catdata;
    }

    @Override
    public Category deleteCategory(Long id) {
        Category categorydata = categoryRepository.findById(id)
                .stream().findAny()
                .orElseThrow(()->new RuntimeException("Requested id is not valid"));
         categoryRepository.delete(categorydata);
        return categorydata;
    }

    @Override
    public Category updateCategory(CategoryRequestDTO categoryRequestDTO, Long id) {
        Category categorydata = categoryRepository.findById(id)
                .stream().findAny()
                .orElseThrow(()->new RuntimeException("Requested id is not valid"));

        categorydata.setCategoryName(categoryRequestDTO.getCategoryName());
        categorydata.setStatus(Status.valueOf(categoryRequestDTO.getStatus()));
        return categoryRepository.save(categorydata);
    }
}

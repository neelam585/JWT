package com.ecom.Testing.dto;

import com.ecom.Testing.model.Product;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CategoryResponseDTO {

    private Long id;

    private String CategoryName;

    private List<Product> products;
}

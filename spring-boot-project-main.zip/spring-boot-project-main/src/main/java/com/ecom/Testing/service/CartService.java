package com.ecom.Testing.service;

import com.ecom.Testing.dto.APIResponse;
import com.ecom.Testing.dto.CartRequestDTO;
import com.ecom.Testing.dto.CartResponseDTO;
import com.ecom.Testing.dto.CartUpdateRequestDTO;

public interface CartService {

    public CartResponseDTO addToCart(CartRequestDTO cartRequestDTO);

    public String deleteCartById(Long cartItemId);

    public String deleteAllItem(Long cartId);

    public String updateCart(CartUpdateRequestDTO cartUpdateRequestDTO);

    public CartResponseDTO getCart();

    String updateAddressInCart(Long addressId);
}

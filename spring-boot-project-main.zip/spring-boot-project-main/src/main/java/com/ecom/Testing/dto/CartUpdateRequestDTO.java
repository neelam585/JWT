package com.ecom.Testing.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.security.PrivateKey;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CartUpdateRequestDTO {

    private Long cartItemId;
    private Integer qty;
}

package com.ecom.Testing.respository;

import com.ecom.Testing.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address,Long> {
}

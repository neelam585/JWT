package com.ecom.Testing.respository;

import com.ecom.Testing.model.CustomerRole;
import com.ecom.Testing.model.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface RoleRespository extends JpaRepository<Roles, Long> {
    Optional<Roles> findByRoleName(CustomerRole enumRole);
}

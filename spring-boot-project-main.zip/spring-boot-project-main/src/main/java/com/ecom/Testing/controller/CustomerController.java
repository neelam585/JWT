package com.ecom.Testing.controller;

import com.ecom.Testing.dto.CustomerRequestDTO;
import com.ecom.Testing.dto.CustomerResponseDTO;
import com.ecom.Testing.dto.LoginDTO;
import com.ecom.Testing.dto.LoginResponseDTO;
import com.ecom.Testing.model.Customer;
import com.ecom.Testing.model.Roles;
import com.ecom.Testing.respository.CustomerRepository;
import com.ecom.Testing.service.CustomerService;
import com.ecom.Testing.service.CustomerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/public/customer")
public class CustomerController {
    @Autowired
    private CustomerServiceImpl customerService;

    @Autowired
    private CustomerRepository customerRepository;

    @PostMapping("/register")
    public ResponseEntity<CustomerResponseDTO> register(@RequestBody CustomerRequestDTO customerRequestDTO){
       CustomerResponseDTO customerData = customerService.register(customerRequestDTO);
       return new ResponseEntity<>(customerData, HttpStatus.CREATED);
    }

    @PostMapping("login")
    public ResponseEntity<LoginResponseDTO> login(@RequestBody LoginDTO loginDTO){
        LoginResponseDTO loginresponse = customerService.login(loginDTO);
        return new ResponseEntity<>(loginresponse,HttpStatus.OK);
    }

    @GetMapping("testing/{customerId}")
    public void Testing(@PathVariable Long customerId){
        Optional<Customer> customerData = customerRepository.findById(customerId);
        if (customerData.isPresent()) {
            List<Roles> roles = customerData.get().getRoles();
            // You can now use `roles` here
        }
        //System.out.println(customer);
    }
}

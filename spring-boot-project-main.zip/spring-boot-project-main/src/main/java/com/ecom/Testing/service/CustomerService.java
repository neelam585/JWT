package com.ecom.Testing.service;

import com.ecom.Testing.dto.CustomerRequestDTO;
import com.ecom.Testing.dto.CustomerResponseDTO;
import com.ecom.Testing.dto.LoginDTO;
import com.ecom.Testing.dto.LoginResponseDTO;
import com.ecom.Testing.model.Customer;

public interface CustomerService {

    public CustomerResponseDTO register(CustomerRequestDTO customerRequestDTO);

    public LoginResponseDTO login(LoginDTO loginDTO);

    public Customer deleteCustomer(Long id);

    public Customer updateCustomer(CustomerRequestDTO customerRequestDTO,Long id);
}

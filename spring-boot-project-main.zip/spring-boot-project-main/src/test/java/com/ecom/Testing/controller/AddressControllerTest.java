package com.ecom.Testing.controller;


import com.ecom.Testing.dto.AddressRequestDTO;
import com.ecom.Testing.model.Address;
import com.ecom.Testing.service.AddressServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
public class AddressControllerTest {

    @Mock
    private AddressServiceImpl addressService;

    @InjectMocks
    private AddressController addressController;

    @Test
    void addressControllerValidate(){
      AddressRequestDTO requestDTO = new AddressRequestDTO();
      requestDTO.setFirstName("santosh");
      requestDTO.setLastName("patel");
      requestDTO.setStreet("test street");
      requestDTO.setCity("delhi");
      requestDTO.setStatus("delhi");
      requestDTO.setMobileNumber("1234567890");
      ResponseEntity<Address> response = addressController.createAddress(requestDTO);
      assertEquals(HttpStatus.CREATED, response.getStatusCode());
    }
}

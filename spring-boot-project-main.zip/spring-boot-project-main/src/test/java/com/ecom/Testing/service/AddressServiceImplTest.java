package com.ecom.Testing.service;

import com.ecom.Testing.dto.AddressRequestDTO;
import com.ecom.Testing.model.Address;
import com.ecom.Testing.respository.AddressRepository;
import org.apache.coyote.BadRequestException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AddressServiceImplTest {

    @Mock
    private AddressRepository addressRepository;

    @Mock
    private ModelMapper modelMapper;

    @InjectMocks
    private AddressServiceImpl addressService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testUpdateAddress_Success() {
        Long addressId = 1L;
        AddressRequestDTO dto = new AddressRequestDTO();
        Address existingAddress = new Address();
        Address updatedAddress = new Address();

        when(addressRepository.findById(addressId)).thenReturn(Optional.of(existingAddress));
        doNothing().when(modelMapper).map(dto, existingAddress);
        when(addressRepository.save(existingAddress)).thenReturn(updatedAddress);

        Address result = addressService.updateAddress(dto, addressId);

        assertNotNull(result);
        verify(addressRepository).findById(addressId);
        verify(modelMapper).map(dto, existingAddress);
        verify(addressRepository).save(existingAddress);
    }

    @Test
    void testUpdateAddress_AddressNotFound() {
        Long addressId = 999L;
        AddressRequestDTO dto = new AddressRequestDTO();

        when(addressRepository.findById(addressId)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                addressService.updateAddress(dto, addressId)
        );

        assertEquals("Address Id does not exist", exception.getMessage());
        verify(addressRepository).findById(addressId);
    }

    @Test
    void testUpdateAddress_DataIntegrityViolation() {
        Long addressId = 1L;
        AddressRequestDTO dto = new AddressRequestDTO();
        Address existingAddress = new Address();

        when(addressRepository.findById(addressId)).thenReturn(Optional.of(existingAddress));
        doNothing().when(modelMapper).map(dto, existingAddress);
        when(addressRepository.save(existingAddress))
                .thenThrow(new org.springframework.dao.DataIntegrityViolationException("Duplicate entry"));

        RuntimeException exception = assertThrows(RuntimeException.class, () ->
                addressService.updateAddress(dto, addressId)
        );

        assertTrue(exception.getCause() instanceof BadRequestException);
        assertTrue(exception.getMessage().contains("Invalid address data"));
    }
}

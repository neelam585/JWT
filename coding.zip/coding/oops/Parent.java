package oops;

public class Parent {
    public void m1(){
        System.out.println("Parent m1");
    }
    public static void m2(){
        System.out.println("Parent static m2");
    }
}
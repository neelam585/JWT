import java.util.*;
import java.lang.Integer;
import java.util.function.Function;
import java.util.stream.*;

public class TestInteger {
    public static void main(String[] args){
        List<Integer> numbers = Arrays.asList(123, 456, 101, 900, 150, 1001, 1234);
        List<Integer> num1 = numbers.stream().map(String::valueOf).filter(n->n.startsWith("1"))
                .map(Integer::valueOf).toList();
        List<String> name = Arrays.asList("Neelam", "Neelam", "Neha", "Geeta");

        List<String> dupName = name.stream()
                .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
                .entrySet().stream()
                .filter(entry->entry.getValue() >1)
                .map(Map.Entry::getKey)
                .toList();

        String input = "Java articles are Awesome";
        Map<Character, Long> str = input.chars().mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
        System.out.println(str);

        Optional<Character> firstNonRepeat = str.entrySet().stream()
                .filter(entry->entry.getValue() == 1)
                .map(Map.Entry::getKey)
                .findFirst();

        Optional<Character> firstRepeat = str.entrySet().stream()
                .filter(entry->entry.getValue() >1)
                .map(Map.Entry::getKey)
                .findFirst();

        Stream.iterate(new int[]{0,1}, t->new int[]{t[1],t[0]+t[1]}).limit(10).map(t->t[0])
                .forEach(System.out::println);

        List<String> words5 = Arrays.asList("apple", "banana", "kiwi", "strawberry");
        String longestWord = words5.stream().max(Comparator.comparing(String::length)).get();
        System.out.println(longestWord);


//remove space and find frequency of each char
        String str1 = "ab8cd syz9";
        Map<Character, Long> replaceSpace = str1.replace(" ", "").chars().mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));

        Map<Character, Long> data1 = str1.chars().filter(i->i !=' ').mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));

        System.out.println("replaceSpace: " + replaceSpace);
        System.out.println("data1: " + data1);

        Map<Character, Long> digitFrequency = str1.chars().filter(Character::isDigit).mapToObj(i->(char)i)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println("digitFrequency: " + digitFrequency);

//filter the digit
        String digitsOnly = str1.chars()
                .filter(Character::isDigit)
                .mapToObj(c -> String.valueOf((char) c))
                .collect(Collectors.joining());

        System.out.println("Digits: " + digitsOnly);

        //-------------------------------------------------------------------------------------------
        String strname = "My name is Neelam. I am from delhi";

        Map<Character, Long> frequency = strname.chars()
                .mapToObj(i->(char)i)
                .filter(i->i != ' ')
                .map(Character::toLowerCase).collect(Collectors.groupingBy(
                        Function.identity(), Collectors.counting()
                ));

        System.out.println(frequency);
        //{a=3, d=1, e=4, f=1, h=1, i=3, l=2, m=5, .=1, n=2, o=1, r=1, s=1, y=1}

        // Check for vowels using Stream API
        boolean hasVowel = strname.toLowerCase()
                .chars() // Convert string to IntStream of character codes
                .mapToObj(c -> (char) c) // Convert character codes to characters
                .anyMatch(ch -> "aeiou".indexOf(ch) != -1); // Check if the character is a vowel

        Boolean status = strname.chars().mapToObj(i->(char)i)
                .map(Character::toLowerCase)
                .anyMatch(ch->"aeiou".indexOf(ch) != -1);
        System.out.println(status);

        System.out.println("Does the string contain any vowels? " + hasVowel);
        //true

    }
}

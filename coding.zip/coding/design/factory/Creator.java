package design.factory;

abstract class Creator {
    public abstract Product factoryMethod();
}

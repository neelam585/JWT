package design.factory;

public class ConcreteProductB implements Product{

    @Override
    public void create() {
        System.out.println("Product B is created");
    }
}

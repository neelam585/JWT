package com.customerorder.customer.service;

import com.customerorder.customer.payload.CustomerRequest;
import com.customerorder.customer.payload.CustomerResponse;

import java.util.List;

public interface CustomerService {
CustomerResponse createCustomer(CustomerRequest customerRequest);
List<CustomerResponse> getCustomers();
CustomerResponse getCustomerById(Long id);
}

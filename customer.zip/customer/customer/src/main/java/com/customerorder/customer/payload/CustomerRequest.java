package com.customerorder.customer.payload;

import com.customerorder.customer.model.Order;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class CustomerRequest {
    private String customerName;
    private String customerAddress;
    private String customerPhone;
    private String password;
    private String email;
    private String gender;
    private List<Order> orders;


}

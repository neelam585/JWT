package com.customerorder.customer.service;

import com.customerorder.customer.CustomerRepository;
import com.customerorder.customer.exceptions.ResourceNotFoundException;
import com.customerorder.customer.model.Customer;
import com.customerorder.customer.model.Order;
import com.customerorder.customer.payload.CustomerRequest;
import com.customerorder.customer.payload.CustomerResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerServiceImpl implements CustomerService{

   @Autowired
    private CustomerRepository customerRepository;

    public CustomerResponse createCustomer(CustomerRequest customerRequest){

        Customer customer = new Customer();
        customer.setCustomerName(customerRequest.getCustomerName());
        customer.setEmail(customerRequest.getEmail());
        customer.setGender(customerRequest.getGender());
        customer.setPassword(customerRequest.getPassword());
        customer.setCustomerAddress(customerRequest.getCustomerAddress());
        customer.setCustomerPhone(customerRequest.getCustomerPhone());
        List<Order> orders = customerRequest.getOrders().stream()
                .map(orderRequest -> {
            Order newOrder = new Order();

            newOrder.setOrderStatus(orderRequest.getOrderStatus());
            newOrder.setOrderTotal(orderRequest.getOrderTotal());
            newOrder.setCustomer(customer);
            return newOrder;
        })
        .collect(Collectors.toList());
        customer.setOrders(orders);
// saved customer and orders
        Customer savedCustomer = customerRepository.save(customer);
        CustomerResponse customerResponse = new CustomerResponse();
        customerResponse.setCustomerName(savedCustomer.getCustomerName());
        customerResponse.setEmail(savedCustomer.getEmail());
        customerResponse.setGender(savedCustomer.getGender());
        customerResponse.setCustomerAddress(savedCustomer.getCustomerAddress());
        customerResponse.setCustomerPhone(savedCustomer.getCustomerPhone());
        customerResponse.setPassword(savedCustomer.getPassword());
        customerResponse.setOrders(savedCustomer.getOrders());
        return customerResponse;
        //Customer savedCustomer =  customerRepository.save(customer);
        // Map saved Customer entity to CustomerResponse dto
        /*CustomerResponse customerResponse = new CustomerResponse();

        customerResponse.setCustomerName(savedCustomer.getCustomerName());
        customerResponse.setEmail(savedCustomer.getEmail());
        customerResponse.setGender(savedCustomer.getGender());

        return customerResponse;*/
    }
    @Override
    public List<CustomerResponse> getCustomers() {

        List<Customer> customerResponses = customerRepository.findAll();
        List<CustomerResponse> customerResponseList = customerResponses.stream()
                .map(customer -> {
                    CustomerResponse customerResponse = new CustomerResponse();
                    customerResponse.setCustomerName(customer.getCustomerName());
                    customerResponse.setEmail(customer.getEmail());
                    customerResponse.setGender(customer.getGender());
                    customerResponse.setCustomerAddress(customer.getCustomerAddress());
                    customerResponse.setCustomerPhone(customer.getCustomerPhone());
                    customerResponse.setPassword(customer.getPassword());
                    customerResponse.setOrders(customer.getOrders());
                    return customerResponse;
                }).collect(Collectors.toList());
        return customerResponseList;
    }
@Override
public CustomerResponse getCustomerById(Long id) {
    Customer customer = customerRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Customer", "Id", id));
    CustomerResponse customerResponse = new CustomerResponse();
    customerResponse.setCustomerName(customer.getCustomerName());
    customerResponse.setEmail(customer.getEmail());
    customerResponse.setGender(customer.getGender());
    customerResponse.setCustomerAddress(customer.getCustomerAddress());
    customerResponse.setCustomerPhone(customer.getCustomerPhone());
    customerResponse.setPassword(customer.getPassword());
    customerResponse.setOrders(customer.getOrders());

    return customerResponse;
}



}

package com.customerorder.customer.payload;

import com.customerorder.customer.model.Order;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerResponse {
    private String customerName;
    private String Email;
    private String Gender;
    private String customerAddress;
    private String customerPhone;
    private String password;
    private List<Order> orders;
}

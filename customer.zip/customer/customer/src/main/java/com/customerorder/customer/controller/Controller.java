package com.customerorder.customer.controller;

import com.customerorder.customer.payload.CustomerRequest;
import com.customerorder.customer.payload.CustomerResponse;
import com.customerorder.customer.payload.OrderRequest;
import com.customerorder.customer.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class Controller {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/customers")
    public ResponseEntity<CustomerResponse> createCustomer(@RequestBody CustomerRequest customerRequest){
        return new ResponseEntity<CustomerResponse>(customerService.createCustomer(customerRequest), HttpStatus.CREATED);
    }
    @GetMapping("/customers")
    public ResponseEntity<List<CustomerResponse>> getCustomers(){
       List<CustomerResponse> customerResponses = customerService.getCustomers();
       return new ResponseEntity<List<CustomerResponse>>(customerResponses, HttpStatus.OK);
    }
    @GetMapping("/customers/{id}")
    public ResponseEntity<CustomerResponse> getCustomerById(@PathVariable Long id){
        CustomerResponse customerResponse = customerService.getCustomerById(id);
        return new ResponseEntity<CustomerResponse>(customerResponse, HttpStatus.OK);
    }
}

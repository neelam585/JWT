package com.ecommerce.project.payload;

import com.ecommerce.project.model.Address;
import com.ecommerce.project.model.Customer;
import lombok.Data;

import java.util.List;

@Data
public class CustomerResponseDTO {

    private List<Customer> content;
    private Integer pageNumber;
    private Integer pageSize;
    private Long totalElements;
    private Integer totalPages;
    private boolean lastPage;


}

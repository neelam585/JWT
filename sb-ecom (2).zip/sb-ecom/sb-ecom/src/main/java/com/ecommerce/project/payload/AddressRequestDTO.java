package com.ecommerce.project.payload;

import lombok.Data;

@Data
public class AddressRequestDTO {
    private String firstName;
    private String lastName;
    private String street;
    private String city;
    private String state;
    private String country;
    private Integer pincode;
    private Boolean status;
    private Long customerId;
    
}

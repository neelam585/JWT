package com.ecommerce.project.config;

import com.ecommerce.project.model.Address;
import com.ecommerce.project.model.Customer;
import com.ecommerce.project.payload.AddressRequestDTO;
import com.ecommerce.project.payload.CustomerRequestDTO;

import java.util.List;
import java.util.stream.Collectors;

//Ensure the CustomerMapper sets the Customer reference for each Address.
public class CustomerMapper {
    public static Customer toEntity(CustomerRequestDTO customerRequestDTO) {
        Customer customer = new Customer();
        customer.setUserName(customerRequestDTO.getUserName());
        customer.setEmail(customerRequestDTO.getEmail());

        if (customerRequestDTO.getAddresses() != null) {
            List<Address> addresses = customerRequestDTO.getAddresses().stream().map(addressRequestDTO -> {
                Address address = new Address();
                address.setStreet(addressRequestDTO.getStreet());
                address.setCity(addressRequestDTO.getCity());
                address.setState(addressRequestDTO.getState());
                address.setPincode(addressRequestDTO.getPincode());
                address.setCustomer(customer); // Set the customer reference
                return address;
            }).collect(Collectors.toList());
            customer.setAddress(addresses);
        }

        return customer;
    }

    public static CustomerRequestDTO toDTO(Customer customer) {
        CustomerRequestDTO customerRequestDTO = new CustomerRequestDTO();
        customerRequestDTO.setUserName(customer.getUserName());
        customerRequestDTO.setEmail(customer.getEmail());

        if (customer.getAddress() != null) {
            List<AddressRequestDTO> addresses = customer.getAddress().stream().map(address -> {
                AddressRequestDTO addressDTO = new AddressRequestDTO();
                addressDTO.setStreet(address.getStreet());
                addressDTO.setCity(address.getCity());
                addressDTO.setState(address.getState());
                addressDTO.setPincode(address.getPincode());
                return addressDTO;
            }).collect(Collectors.toList());
            customerRequestDTO.setAddresses(addresses);
        }

        return customerRequestDTO;
    }
}

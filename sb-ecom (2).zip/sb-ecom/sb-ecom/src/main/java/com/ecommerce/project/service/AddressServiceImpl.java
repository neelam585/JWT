package com.ecommerce.project.service;

import com.ecommerce.project.model.Address;
import com.ecommerce.project.payload.AddressRequestDTO;
import com.ecommerce.project.repositories.AddressRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class AddressServiceImpl implements AddressService {
    @Autowired
    private AddressRepository addressRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Address createAddress(AddressRequestDTO addressRequestDTO){
        Address address = modelMapper.map(addressRequestDTO, Address.class);
        return addressRepository.save(address);
    }

    @Override
    public List<Address> getAllAddressr(){
        return addressRepository.findAll();

    }
    @Override
    public Address getAddressById(Long addressId){
        return addressRepository.findById(addressId)
                .orElseThrow(()->new RuntimeException("Address not found with id:" +addressId));
    }
    @Override
    public void deleteAddressById(Long addressId){
        addressRepository.deleteById(addressId);

    }
}

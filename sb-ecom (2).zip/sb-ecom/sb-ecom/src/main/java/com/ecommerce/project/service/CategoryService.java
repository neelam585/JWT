package com.ecommerce.project.service;

import com.ecommerce.project.model.Category;

import java.util.List;

public interface CategoryService {
    // Create a new category
    Category createCategory(Category category);

    // Get a category by its ID
    Category getCategoryById(Long categoryId);

    // Get all categories
    List<Category> getAllCategories();

    // Update a category by its ID
    Category updateCategory(Long categoryId, Category category);

    // Delete a category by its ID
    void deleteCategoryById(Long categoryId);


}

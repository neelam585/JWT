package com.ecommerce.project.exception;

public class APIException {
}

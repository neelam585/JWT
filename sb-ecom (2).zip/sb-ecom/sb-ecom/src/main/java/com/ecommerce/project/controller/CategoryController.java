package com.ecommerce.project.controller;

import com.ecommerce.project.model.Category;
import com.ecommerce.project.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class CategoryController {
    @Autowired
     private CategoryService categoryService;

     @PostMapping("/categories")
     public void createCategory(@RequestBody Category category){
          categoryService.createCategory(category);

     }

     @GetMapping("/categories")
     public List<Category> getAllCategories(){
         return categoryService.getAllCategories();
     }

     @DeleteMapping("/delete/categories/{id}")
    public void deleteCategoryById(@PathVariable Long id){
         categoryService.deleteCategoryById(id);
     }

     @PutMapping("update/categories/{id}")
    public Category updateCategory(@PathVariable Long id, @RequestBody Category category){
         return categoryService.updateCategory(id, category);
     }

}

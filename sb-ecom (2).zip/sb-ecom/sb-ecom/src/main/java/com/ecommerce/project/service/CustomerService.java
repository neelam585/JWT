package com.ecommerce.project.service;

import com.ecommerce.project.model.Customer;
import com.ecommerce.project.payload.CustomerRequestDTO;
import com.ecommerce.project.payload.CustomerResponseDTO;

import java.util.List;

public interface CustomerService {
    Customer createCustomer(CustomerRequestDTO customerRequestDTO);
    CustomerResponseDTO getAllCustomers(Integer page, Integer size);
    Customer deleteCustomerById(Long customerId);
    List<Customer> searchCustomers(String name, String email);
    Customer getCustomerById(Long customerId);
 /*   List<Customer> searchByName(String name);

    List<Customer> searchByEmail(String email);*/
}

package com.ecommerce.project.service;

import com.ecommerce.project.model.Product;
import com.ecommerce.project.repositories.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    private ProductRepository productRepository;


    @Override
    public void createProduct(Product product){
        productRepository.save(product);
    }

    @Override
    public Product getProductById(Long productId){
        return productRepository.findById(productId)
                .orElseThrow(()->new RuntimeException("Product Not with id:" + productId));
    }

    @Override
    public List<Product> getAllProduct(){
        return productRepository.findAll();
    }
}

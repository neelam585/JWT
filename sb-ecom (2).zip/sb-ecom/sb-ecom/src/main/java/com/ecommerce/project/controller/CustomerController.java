package com.ecommerce.project.controller;

import com.ecommerce.project.model.Customer;
import com.ecommerce.project.payload.CustomerRequestDTO;
import com.ecommerce.project.payload.CustomerResponseDTO;
import com.ecommerce.project.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/customer")
    public Customer createCustomer(@Valid @RequestBody CustomerRequestDTO customerRequestDTO){
       return customerService.createCustomer(customerRequestDTO);
    }

    @GetMapping("/customer")
    public CustomerResponseDTO getAllCustomers( @RequestParam(name = "pageNumber", required = false) Integer pageNumber,
                                               @RequestParam(name = "pageSize", required = false) Integer pageSize){
        return customerService.getAllCustomers(pageNumber,pageSize);
    }
    @DeleteMapping("/delete/customer/{id}")
    public Customer deleteCustomerById(@PathVariable Long id){
        return customerService.deleteCustomerById(id);
    }
    @GetMapping("/search")
    public List<Customer> searchCustomers(
            @RequestParam(value = "ame", required = false) String name,
            @RequestParam(value = "email", required = false) String email)
            {
        return customerService.searchCustomers(name, email);
    }
@GetMapping("/customer/{id}")
    public Customer getCustomerById(@PathVariable Long id){
        return customerService.getCustomerById(id);
}

}

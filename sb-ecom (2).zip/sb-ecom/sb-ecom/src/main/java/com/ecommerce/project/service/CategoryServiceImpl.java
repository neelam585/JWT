package com.ecommerce.project.service;

import com.ecommerce.project.model.Category;
import com.ecommerce.project.repositories.CategoryRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
//@Transactional
public class CategoryServiceImpl implements CategoryService{
    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public Category createCategory(Category category){
        return categoryRepository.save(category);

    }
    @Override
    public List<Category> getAllCategories(){
        return categoryRepository.findAll();
    }


    @Override
    public Category getCategoryById(Long categoryId){
        return categoryRepository.findById(categoryId)
                .orElseThrow(()->new RuntimeException("Category Not with Id: " +categoryId));
    }
    @Override
    public Category updateCategory(Long categoryId, Category category){
        Category categoryy1 =  getCategoryById(categoryId);
        categoryy1.setCategoryName(category.getCategoryName());
        return categoryRepository.save(categoryy1);
    }
    @Override
    public void deleteCategoryById(Long categoryId){

        categoryRepository.deleteById(categoryId);
    }
}

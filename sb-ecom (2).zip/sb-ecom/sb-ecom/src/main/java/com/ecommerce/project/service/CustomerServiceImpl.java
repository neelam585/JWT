package com.ecommerce.project.service;

import com.ecommerce.project.exception.ResourceNotFoundException;
import com.ecommerce.project.model.Customer;
import com.ecommerce.project.payload.CustomerResponseDTO;
import com.ecommerce.project.payload.CustomerRequestDTO;
import com.ecommerce.project.repositories.CustomerRepository;
import com.ecommerce.project.repositories.CustomerSpecification;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public  class CustomerServiceImpl implements CustomerService{

    @Autowired
    private CustomerRepository customerRepository;
@Autowired
private ModelMapper modelMapper;

    @Override
    public Customer createCustomer(CustomerRequestDTO customerRequestDTO){
        /*Customer customerData = new Customer();
        customerData.setFirstName(customerRequestDTO.getFirstName());
        customerData.setLastName(customerRequestDTO.getLastName());
        customerData.setEmail(customerRequestDTO.getEmail());
        customerData.setUserName(customerRequestDTO.getUserName());
        customerData.setPassword(customerRequestDTO.getPassword());
        customerData.setStatus(customerRequestDTO.getStatus());*/
        Customer category = modelMapper.map(customerRequestDTO, Customer.class);
        return customerRepository.save(category);

    }
@Override
    public Customer getCustomerById(Long customerId) {
        return customerRepository.findById(customerId).orElseThrow(() ->
                new RuntimeException("Customer not found"));
    }
    @Override
    public CustomerResponseDTO getAllCustomers(Integer page, Integer size){

        Pageable pageDetails = PageRequest.of(page, size);
        Page<Customer> pageProducts = customerRepository.findAll(pageDetails);

        List<Customer> customer = pageProducts.getContent();

        List<Customer> productDTOS = customer.stream()
                .map(customerData -> modelMapper.map(customerData, Customer.class))
                .toList();


        CustomerResponseDTO customerResponseDTO = new CustomerResponseDTO();
        customerResponseDTO.setContent(productDTOS);
        customerResponseDTO.setPageNumber(pageProducts.getNumber());
        customerResponseDTO.setPageSize(pageProducts.getSize());
        customerResponseDTO.setTotalElements(pageProducts.getTotalElements());
        customerResponseDTO.setTotalPages(pageProducts.getTotalPages());
        customerResponseDTO.setLastPage(pageProducts.isLast());
        return customerResponseDTO;
      //  Customer customerRepository.findAll(PageRequest.of(page, size));
    }
    @Override
    public Customer deleteCustomerById(Long customerId){

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer","customerId",customerId));
        customerRepository.delete(customer);
        return customer;

    }
    public List<Customer> searchCustomers(String name, String email) {
        Specification<Customer> spec = Specification.where(null);

        if (name != null) {
            spec = spec.and(CustomerSpecification.hasName(name));
        }
        if (email != null) {
            spec = spec.and(CustomerSpecification.hasEmail(email));
        }

        return customerRepository.findAll(spec);
    }


}

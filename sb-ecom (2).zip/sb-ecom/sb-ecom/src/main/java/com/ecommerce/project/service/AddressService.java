package com.ecommerce.project.service;

import com.ecommerce.project.model.Address;
import com.ecommerce.project.payload.AddressRequestDTO;

import java.util.List;

public interface AddressService {
    Address createAddress(AddressRequestDTO addressRequestDTO);
    List<Address> getAllAddressr();
    Address getAddressById(Long addressId);
    void deleteAddressById(Long addressId);
}

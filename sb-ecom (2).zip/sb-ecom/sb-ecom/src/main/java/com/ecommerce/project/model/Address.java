package com.ecommerce.project.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.apachecommons.CommonsLog;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long addressId;
    private String FirstName;
    private String LastName;
    private String street;
    private String city;
    private String state;
    private String country;
    private Integer pincode;
    @ManyToOne
    private Customer customer;
    private Boolean status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

package com.ecommerce.project.payload;

import com.ecommerce.project.model.Address;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Collate;

import java.util.List;

@Data
public class CustomerRequestDTO {
    private String firstName;
    private String lastName;
    private String userName;
    @Email(message = "Email formate is not Valid")
    @NotBlank(message = "Email is mandatory")
    @Column(unique = true)
    private String email;
    private String password;
    private Boolean status;
    private List<AddressRequestDTO> addresses;


}

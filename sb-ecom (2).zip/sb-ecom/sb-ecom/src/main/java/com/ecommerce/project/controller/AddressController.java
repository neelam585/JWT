package com.ecommerce.project.controller;

import com.ecommerce.project.model.Address;
import com.ecommerce.project.payload.AddressRequestDTO;
import com.ecommerce.project.service.AddressService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class AddressController {
    @Autowired
    AddressService addressService;

    @PostMapping("/address")
    public Address createAddress(@Valid @RequestBody AddressRequestDTO addressRequestDTO){
        return addressService.createAddress(addressRequestDTO);

    }
   @GetMapping("/address")
   public List<Address> getAllAddress(){
        return addressService.getAllAddressr();
   }
   @GetMapping("/address/{id}")
    public Address getAddressById(@PathVariable Long id){
        return addressService.getAddressById(id);
   }
   @DeleteMapping("/address/{id}")
    public void deleteAddressById(@PathVariable Long id){
        addressService.getAddressById(id);
   }

}
